$('a').on('click', function(){
    var target = $(this).data('target');
    var pos = $(target).offset().top;
    $('html, body').animate({'scrollTop': pos - 200}, 500);
  });
  document.getElementById("CIA IRASYTI ID").scrollIntoView({behavior: "smooth"})